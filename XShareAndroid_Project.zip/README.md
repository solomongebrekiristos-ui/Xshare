# XShare Android (starter implementation)

XShare is a native Android file-sharing MVP. It contains:
- Local HTTP receiving server (NanoHTTPD)
- QR code pairing for phones on the same Wi-Fi/hotspot
- File picker and HTTP upload
- Wi-Fi Direct peer discovery and connection UI

## Important current MVP limits
- Wi-Fi Direct discovery/connection is implemented, but the app currently asks the receiving phone to start receiving and show its QR after the peer connection. Depending on Android vendor/version, the app may need to be reopened or Wi-Fi Direct permissions granted.
- The QR transfer path uses the current local IPv4 address and port 8765. Both phones must be on the same reachable local network. Some Android hotspot configurations isolate clients or use a different interface address.
- Received files are stored in the app-specific folder `Android/data/com.example.xshare/files/XShare`. They are not placed in the public Downloads folder yet.
- This is a starter project, not a signed installable APK. Build it with Android Studio and test on two real Android phones before relying on it.
- Transfers are unencrypted HTTP on the local network. Use only on a trusted network and with people you intend to share with. Do not use public Wi-Fi.

## Build APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync. Install Android SDK 35 if Android Studio asks.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.

## Test
1. Install the app on two Android phones.
2. Connect both phones to the same Wi-Fi, or turn on a hotspot on one phone and connect the other.
3. On the receiving phone, tap **START RECEIVING**. Keep the app open; a QR code should appear.
4. On the sending phone, tap **SCAN QR & SEND FILE**, scan the QR, and choose a file.
5. Confirm the received file in the app-specific XShare folder.

## Wi-Fi Direct
1. Keep Wi-Fi enabled on both phones.
2. On the receiving phone, tap **FIND NEARBY PHONE** and select the sender (or reverse the roles).
3. After the connection is established, start receiving on the receiving phone and scan its QR from the sender.
4. If Android blocks discovery, grant Nearby devices (Android 13+) or Location (Android 12 and older) permission, and check the phone's Wi-Fi Direct support.

## Security / privacy
The app does not upload files to a cloud server. It runs a temporary local server on the receiving phone. Stop receiving when finished. The app currently has no authentication or encryption, so only use a trusted private connection.
