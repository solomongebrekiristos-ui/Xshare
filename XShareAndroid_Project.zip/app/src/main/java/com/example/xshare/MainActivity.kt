package com.example.xshare

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.net.wifi.p2p.*
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var qr: ImageView
    private lateinit var peersBox: LinearLayout
    private var server: TransferServer? = null
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private var receiver: BroadcastReceiver? = null
    private var targetUrl: String? = null

    private val chooseFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) sendFile(uri)
    }
    private val scanQr = registerForActivityResult(ScanContract()) { result ->
        val contents = result.contents
        if (!contents.isNullOrBlank() && contents.startsWith("http://")) {
            targetUrl = contents.trimEnd('/')
            status.text = "Receiver found. Choose a file to send."
            chooseFile.launch("*/*")
        } else if (contents != null) status.text = "QR code is not a valid XShare receiver."
    }
    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        status.text = "Permissions updated. Try starting receive or Wi-Fi Direct again."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper, null)
        buildUi()
        requestNeededPermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.rgb(245, 248, 255))
        }
        val title = TextView(this).apply {
            text = "XShare"
            textSize = 32f
            setTextColor(Color.rgb(11, 61, 145))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Share files nearby — no internet required"
            textSize = 14f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Ready. Connect both phones to the same Wi-Fi or hotspot."
            textSize = 14f
            setPadding(8, 18, 8, 18)
        }
        qr = ImageView(this).apply {
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(260, 260).apply { gravity = Gravity.CENTER }
        }
        peersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(makeButton("START RECEIVING (Wi-Fi / Hotspot)") { startReceiver() })
        root.addView(qr)
        root.addView(makeButton("SCAN QR & SEND FILE") { scanQr.launch(ScanOptions().setPrompt("Scan the receiver's XShare QR code").setBeepEnabled(false)) })
        root.addView(makeButton("FIND NEARBY PHONE (Wi-Fi Direct)") { discoverPeers() })
        root.addView(peersBox)
        root.addView(makeButton("STOP RECEIVING") {
            server?.stop(); server = null; qr.setImageBitmap(null)
            status.text = "Receiver stopped."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = 8; bottomMargin = 8
            }
        }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (needed.isNotEmpty()) permissionRequest.launch(needed.toTypedArray())
    }

    private fun startReceiver() {
        try {
            server?.stop()
            val folder = getExternalFilesDir("XShare") ?: filesDir
            server = TransferServer(folder)
            server!!.start()
            val ip = getLocalIpv4()
            if (ip == null) {
                status.text = "Server started, but no local IP found. Connect to a hotspot/Wi-Fi first."
                return
            }
            val url = "http://$ip:8765"
            status.text = "Receiving is ON. Other phone: scan this QR. Saved in Android/data/.../files/XShare"
            showQr(url)
        } catch (e: Exception) {
            status.text = "Could not start receiver: ${e.message}"
        }
    }

    private fun showQr(value: String) {
        val matrix = MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, 600, 600)
        val bitmap = Bitmap.createBitmap(600, 600, Bitmap.Config.RGB_565)
        for (x in 0 until 600) for (y in 0 until 600)
            bitmap.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        qr.setImageBitmap(bitmap)
    }

    private fun getLocalIpv4(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val addresses = interfaces.nextElement().inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address && address.isSiteLocalAddress)
                        return address.hostAddress
                }
            }
        } catch (_: Exception) {}
        return null
    }

    private fun discoverPeers() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions(); status.text = "Allow Nearby devices permission, then try again."; return
        }
        peersBox.removeAllViews()
        status.text = "Searching for nearby Wi-Fi Direct devices..."
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        }
        receiver?.let { unregisterReceiver(it) }
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION) {
                    manager.requestPeers(channel) { list ->
                        peersBox.removeAllViews()
                        if (list.deviceList.isEmpty()) status.text = "No devices found. Keep Wi-Fi on and retry."
                        list.deviceList.forEach { device ->
                            peersBox.addView(makeButton("Connect to ${device.deviceName}") {
                                val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
                                manager.connect(channel, config, object : WifiP2pManager.ActionListener {
                                    override fun onSuccess() { status.text = "Connecting to ${device.deviceName}..." }
                                    override fun onFailure(reason: Int) { status.text = "Connection failed: $reason" }
                                })
                            })
                        }
                    }
                }
                if (intent.action == WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION) {
                    manager.requestConnectionInfo(channel) { info ->
                        if (info.groupFormed) {
                            status.text = "Wi-Fi Direct connected. On the receiving phone tap START RECEIVING, then scan its QR."
                        }
                    }
                }
            }
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { status.text = "Scanning... Select a phone when it appears." }
            override fun onFailure(reason: Int) { status.text = "Wi-Fi Direct scan failed ($reason). Check Wi-Fi and permissions." }
        })
    }

    private fun sendFile(uri: Uri) {
        val base = targetUrl ?: run { status.text = "Scan the receiver QR first."; return }
        status.text = "Preparing file..."
        Thread {
            try {
                val name = queryName(uri)
                val temp = File(cacheDir, "outgoing_${System.currentTimeMillis()}")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot open selected file" }.use { source ->
                        temp.outputStream().use { output -> source.copyTo(output) }
                    }
                }
                val boundary = "XShareBoundary${System.currentTimeMillis()}"
                val connection = java.net.URL("$base/upload?name=${java.net.URLEncoder.encode(name, "UTF-8")}").openConnection() as java.net.HttpURLConnection
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.connectTimeout = 15000
                connection.readTimeout = 60000
                connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                connection.outputStream.use { out ->
                    out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"upload.bin\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray())
                    temp.inputStream().use { it.copyTo(out) }
                    out.write("\r\n--$boundary--\r\n".toByteArray())
                }
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                temp.delete()
                runOnUiThread { status.text = "Transfer complete: $response" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Transfer failed: ${e.message}. Check both phones are on the same network." }
            }
        }.start()
    }

    private fun queryName(uri: Uri): String {
        var name = "shared_file"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }

    override fun onDestroy() {
        server?.stop()
        receiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
