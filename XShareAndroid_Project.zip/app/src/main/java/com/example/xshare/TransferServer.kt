package com.example.xshare

import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileOutputStream

class TransferServer(private val destination: File, port: Int = 8765) : NanoHTTPD(port) {
    override fun serve(session: IHTTPSession): Response {
        if (session.method == Method.GET && session.uri == "/") {
            return newFixedLengthResponse(
                Response.Status.OK, "text/plain",
                "XShare receiver is ready. Send a file using the XShare app."
            )
        }
        if (session.method == Method.POST && session.uri == "/upload") {
            return try {
                val files = HashMap<String, String>()
                session.parseBody(files)
                val tempPath = files["file"] ?: return newFixedLengthResponse(
                    Response.Status.BAD_REQUEST, "text/plain", "No file received"
                )
                val rawName = session.parameters["name"]?.firstOrNull() ?: "received_file"
                val safeName = File(rawName).name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
                    .take(120).ifBlank { "received_file" }
                if (!destination.exists()) destination.mkdirs()
                val output = File(destination, safeName)
                File(tempPath).inputStream().use { input ->
                    FileOutputStream(output).use { out -> input.copyTo(out) }
                }
                newFixedLengthResponse(Response.Status.OK, "text/plain", "Received: ${output.name}")
            } catch (e: Exception) {
                newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "Transfer failed: ${e.message}")
            }
        }
        return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
    }
}
